#!/bin/bash
# setup.sh - Setup script for PAM REST API module

set -e

echo "PAM REST API Authentication Module Setup"
echo "======================================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (use sudo)"
    exit 1
fi

# Check for required dependencies
echo "Checking dependencies..."

DEPS_MISSING=0

# Check for development packages
for pkg in libpam0g-dev libcurl4-openssl-dev libjson-c-dev; do
    if ! dpkg -l | grep -q "^ii  $pkg"; then
        echo "Missing: $pkg"
        DEPS_MISSING=1
    fi
done

if [ $DEPS_MISSING -eq 1 ]; then
    echo ""
    echo "Installing missing dependencies..."
    apt-get update
    apt-get install -y libpam0g-dev libcurl4-openssl-dev libjson-c-dev build-essential
fi

# Compile the module
echo ""
echo "Compiling PAM module..."
make clean
make

# Install the module
echo ""
echo "Installing PAM module..."
make install

# Create example PAM configuration
echo ""
echo "Creating example PAM configurations..."

# Example for SSH
cat > /etc/pam.d/sshd-restapi-example << 'EOF'
# PAM configuration for SSH with REST API authentication
# Copy this to /etc/pam.d/sshd to use

# Standard Unix authentication (comment out to disable local auth)
#@include common-auth

# REST API authentication (uncomment to enable)
auth    required    pam_elogin_api.so
auth    required    pam_permit.so

# Standard account management
account    required    pam_nologin.so
@include common-account

# Standard session management
session    [success=ok ignore=ignore module_unknown=ignore default=bad]    pam_selinux.so close
session    required    pam_loginuid.so
session    optional    pam_keyinit.so force revoke
@include common-session
session    optional    pam_motd.so motd=/run/motd.dynamic
session    optional    pam_motd.so noupdate
session    optional    pam_mail.so standard noenv
session    required    pam_limits.so
session    required    pam_env.so
session    required    pam_env.so user_readenv=1 envfile=/etc/default/locale
session    [success=ok ignore=ignore module_unknown=ignore default=bad]    pam_selinux.so open

# Standard password management
@include common-password
EOF

# Example for sudo
cat > /etc/pam.d/sudo-restapi-example << 'EOF'
# PAM configuration for sudo with REST API authentication
# Copy this to /etc/pam.d/sudo to use

# REST API authentication
auth    required    pam_elogin_api.so
auth    required    pam_permit.so

# Standard sudo configuration
@include common-account
@include common-session-noninteractive
EOF

# Create test script
cat > /usr/local/bin/test-pam-rest-api << 'EOF'
#!/bin/bash
# Test script for PAM REST API authentication

echo "Testing PAM REST API Authentication"
echo "==================================="
echo ""
echo "This will test the authentication using the pamtester utility."
echo ""

# Check if pamtester is installed
if ! command -v pamtester &> /dev/null; then
    echo "Installing pamtester..."
    apt-get install -y pamtester
fi

# Create test PAM service
cat > /etc/pam.d/test-rest-api << 'EOC'
auth    required    pam_elogin_api.so
account required    pam_permit.so
EOC

echo "Enter credentials to test:"
read -p "Username: " username
read -s -p "Password: " password
echo ""

# Test authentication
if pamtester test-rest-api $username authenticate <<< "$password"; then
    echo "Authentication successful!"
else
    echo "Authentication failed!"
fi

# Cleanup
rm -f /etc/pam.d/test-rest-api
EOF

chmod +x /usr/local/bin/test-pam-rest-api

echo ""
echo "Setup complete!"
echo ""
echo "=== USAGE INSTRUCTIONS ==="
echo ""
echo "1. Test the module:"
echo "   sudo test-pam-rest-api"
echo ""
echo "2. Example PAM configurations have been created:"
echo "   - /etc/pam.d/sshd-restapi-example (for SSH)"
echo "   - /etc/pam.d/sudo-restapi-example (for sudo)"
echo ""
echo "3. To enable REST API authentication for a service:"
echo "   - Back up the original PAM config: cp /etc/pam.d/SERVICE /etc/pam.d/SERVICE.backup"
echo "   - Edit /etc/pam.d/SERVICE and add: auth required pam_elogin_api.so"
echo ""
echo "4. To monitor authentication attempts:"
echo "   tail -f /var/log/auth.log | grep pam_elogin_api"
echo ""
echo "=== SECURITY NOTES ==="
echo "- This module sends credentials over HTTPS to the API"
echo "- Ensure the API endpoint is trusted and uses valid SSL certificates"
echo "- Consider implementing rate limiting and fail2ban rules"
echo "- Test thoroughly before deploying to production"
echo ""