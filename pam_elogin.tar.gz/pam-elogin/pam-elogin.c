// Compile: gcc -fPIC -shared pam-elogin.c -o pam_elogin.so
#define PAM_SM_AUTH
#include <security/pam_appl.h>
#include <security/pam_modules.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

PAM_EXTERN int pam_sm_authenticate(pam_handle_t *pamh, int flags, int argc, const char **argv) {
        const char *username;
        const char *password;
        int retval;
        char command[256];
        char buffer[1024];
        FILE *pipe;

        retval = pam_get_user(pamh, &username, NULL);
        if (retval != PAM_SUCCESS) {
                return retval;
        }

        const struct pam_conv *conv;
        struct pam_message *msg_temp;
        const struct pam_message *msg;
        struct pam_response *resp;

        retval = pam_get_item(pamh, PAM_CONV, (void *)&conv);
        if (retval != PAM_SUCCESS) {
                return retval;
        }

        msg_temp = (struct pam_message *)malloc(sizeof(struct pam_message));
        if (msg_temp == NULL) {
                return PAM_BUF_ERR;
        }
        msg_temp->msg_style = PAM_PROMPT_ECHO_OFF;
        msg_temp->msg = "Password: ";
        msg = (const struct pam_message *)msg_temp;

        retval = conv->conv(1, &msg, &resp, conv->appdata_ptr);
        free(msg_temp);

        if (retval != PAM_SUCCESS) {
                return retval;
        }

        password = resp->resp;

        // Check if user is valid
        // snprintf(command, sizeof(command),  "echo \'%s\' | /usr/local/bin/elogin --checkuser", username);
        // pipe = popen(command, "r");
        // if (pipe == NULL) {
        //         return PAM_AUTH_ERR;
        // }
        // fgets(buffer, sizeof(buffer), pipe);
        // pclose(pipe);

        // if (strstr(buffer, "invalid") != NULL) {
        //         return PAM_AUTH_ERR;
        // }

        // Call Go program for authentication
        // snprintf(command, sizeof(command), "echo -e \'%s\\n%s\' | /usr/local/bin/elogin", username, password);
        snprintf(command, sizeof(command), "PAM_USER=%s PAM_AUTHTOK=%s /usr/local/bin/pam-elogin", username, password);
        pipe = popen(command, "r");
        if (pipe == NULL) {
                return PAM_AUTH_ERR;
        }

        fgets(buffer, sizeof(buffer), pipe);
        int exit_code = pclose(pipe);

        if (exit_code != 0) {
                return PAM_AUTH_ERR;
        }

        return PAM_SUCCESS;
}

PAM_EXTERN int pam_sm_setcred(pam_handle_t *pamh, int flags, int argc, const char **argv) {
        return PAM_SUCCESS;
}

PAM_EXTERN int pam_sm_acct_mgmt(pam_handle_t *pamh, int flags, int argc, const char **argv) {
        return PAM_SUCCESS;
}

PAM_EXTERN int pam_sm_open_session(pam_handle_t *pamh, int flags, int argc, const char **argv) {
        return PAM_SUCCESS;
}

PAM_EXTERN int pam_sm_close_session(pam_handle_t *pamh, int flags, int argc, const char **argv) {
        return PAM_SUCCESS;
}

PAM_EXTERN int pam_sm_chauthtok(pam_handle_t *pamh, int flags, int argc, const char **argv) {
        return PAM_SUCCESS;
}