// pam_elogin_api.c
// PAM module for authentication via elogin REST API

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <security/pam_appl.h>
#include <security/pam_modules.h>
#include <security/pam_ext.h>
#include <curl/curl.h>
#include <json-c/json.h>
#include <syslog.h>

#define API_URL "https://api.rmutsv.ac.th/elogin"
#define BUFFER_SIZE 4096

// Structure to hold response data
struct response_data {
    char *data;
    size_t size;
};

// Callback function for CURL to handle response
static size_t write_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t total_size = size * nmemb;
    struct response_data *mem = (struct response_data *)userp;
    
    char *ptr = realloc(mem->data, mem->size + total_size + 1);
    if (ptr == NULL) {
        return 0;
    }
    
    mem->data = ptr;
    memcpy(&(mem->data[mem->size]), contents, total_size);
    mem->size += total_size;
    mem->data[mem->size] = 0;
    
    return total_size;
}

// Function to perform API authentication
static int authenticate_via_api(const char *username, const char *password) {
    CURL *curl;
    CURLcode res;
    struct response_data response = {0};
    int ret = PAM_AUTH_ERR;
    
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    
    if (curl) {
        // Prepare JSON POST data
        char post_data[BUFFER_SIZE];
//         snprintf(post_data, sizeof(post_data), 
//                 "username=%s&password=%s", username, password);
        int written = snprintf(post_data, sizeof(post_data), 
                "{\"username\":\"%s\",\"password\":\"%s\"}", username, password);
        if (written < 0 || (size_t)written >= sizeof(post_data)) {
            syslog(LOG_ERR, "pam_elogin_api: post_data buffer too small for username/password");
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return PAM_SERVICE_ERR;
        }
        
        // Set CURL options
        curl_easy_setopt(curl, CURLOPT_URL, API_URL);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_data);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&response);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 1L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
        
//         // Add Content-Type header
//         struct curl_slist *headers = NULL;
//         headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
//         curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        // Add Content-Type header for JSON
        struct curl_slist *headers = NULL;
        headers = curl_slist_append(headers, "Content-Type: application/json");
        headers = curl_slist_append(headers, "Accept: application/json");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        
        // Perform the request
        res = curl_easy_perform(curl);
        
        if (res == CURLE_OK) {
            // Parse JSON response
            struct json_object *parsed_json;
            struct json_object *status;
            
            parsed_json = json_tokener_parse(response.data);
            
            if (parsed_json != NULL) {
                if (json_object_object_get_ex(parsed_json, "status", &status)) {
                    const char *status_str = json_object_get_string(status);
                    
                    if (strcmp(status_str, "ok") == 0) {
                        ret = PAM_SUCCESS;
                        syslog(LOG_INFO, "pam_elogin_api: Authentication successful for user %s", username);
                    } else if (strcmp(status_str, "password") == 0) {
                        ret = PAM_AUTH_ERR;
                        syslog(LOG_WARNING, "pam_elogin_api: Invalid credentials for user %s", username);
                    } else {
                        ret = PAM_SERVICE_ERR;
                        syslog(LOG_ERR, "pam_elogin_api: API error: %s", status_str);
                    }
                }
                json_object_put(parsed_json);
            } else {
                syslog(LOG_ERR, "pam_elogin_api: Failed to parse JSON response");
                ret = PAM_SERVICE_ERR;
            }
        } else {
            syslog(LOG_ERR, "pam_elogin_api: CURL error: %s", curl_easy_strerror(res));
            ret = PAM_SERVICE_ERR;
        }
        
        curl_slist_free_all(headers);
        curl_easy_cleanup(curl);
    }
    
    if (response.data) {
        free(response.data);
    }
    
    curl_global_cleanup();
    return ret;
}

// PAM authentication function
PAM_EXTERN int pam_sm_authenticate(pam_handle_t *pamh, int flags,
                                   int argc, const char **argv) {
    const char *username;
    const char *password;
    int ret;
    
    // Open syslog
    openlog("pam_elogin_api", LOG_PID, LOG_AUTH);
    
    // Get username
    ret = pam_get_user(pamh, &username, "Username: ");
    if (ret != PAM_SUCCESS) {
        syslog(LOG_ERR, "pam_elogin_api: Failed to get username");
        closelog();
        return ret;
    }
    
    // Get password
    ret = pam_get_authtok(pamh, PAM_AUTHTOK, &password, "Password: ");
    if (ret != PAM_SUCCESS) {
        syslog(LOG_ERR, "pam_elogin_api: Failed to get password");
        closelog();
        return ret;
    }
    
    // Perform authentication
    ret = authenticate_via_api(username, password);
    
    closelog();
    return ret;
}

// PAM credential setting function
PAM_EXTERN int pam_sm_setcred(pam_handle_t *pamh, int flags,
                               int argc, const char **argv) {
    return PAM_SUCCESS;
}

// PAM account management function
PAM_EXTERN int pam_sm_acct_mgmt(pam_handle_t *pamh, int flags,
                                 int argc, const char **argv) {
    return PAM_SUCCESS;
}

// PAM session opening function
PAM_EXTERN int pam_sm_open_session(pam_handle_t *pamh, int flags,
                                    int argc, const char **argv) {
    return PAM_SUCCESS;
}

// PAM session closing function
PAM_EXTERN int pam_sm_close_session(pam_handle_t *pamh, int flags,
                                     int argc, const char **argv) {
    return PAM_SUCCESS;
}

// PAM password changing function
PAM_EXTERN int pam_sm_chauthtok(pam_handle_t *pamh, int flags,
                                 int argc, const char **argv) {
    return PAM_SERVICE_ERR;
}